// Edge Function: manage-user  (hanya Manajer) – buat / ubah / hapus akun login
import { createClient } from 'npm:@supabase/supabase-js@2'
const DOM = '@ict.local'
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }
const j = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const caller = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } })
    const { data: { user } } = await caller.auth.getUser()
    if (!user) return j({ error: 'Belum login' }, 401)
    const adm = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const { data: me } = await adm.from('records').select('data').eq('collection', 'users').eq('id', user.id).maybeSingle()
    if (me?.data?.role !== 'Manajer') return j({ error: 'Hanya Manajer yang boleh mengelola user' }, 403)

    const b = await req.json()
    const email = b.username ? `${String(b.username).toLowerCase()}${DOM}` : undefined
    if (b.action === 'create') {
      const { data, error } = await adm.auth.admin.createUser({ email, password: b.password, email_confirm: true })
      if (error) return j({ error: error.message }, 400)
      return j({ id: data.user.id })
    }
    if (b.action === 'update') {
      const patch: Record<string, unknown> = {}
      if (b.password) patch.password = b.password
      if (email) patch.email = email
      if (Object.keys(patch).length) {
        const { error } = await adm.auth.admin.updateUserById(b.id, patch)
        if (error) return j({ error: error.message }, 400)
      }
      return j({ ok: true })
    }
    if (b.action === 'delete') {
      if (b.id === user.id) return j({ error: 'Tidak bisa menghapus akun sendiri' }, 400)
      const { error } = await adm.auth.admin.deleteUser(b.id)
      if (error) return j({ error: error.message }, 400)
      return j({ ok: true })
    }
    return j({ error: 'Aksi tidak dikenal' }, 400)
  } catch (e) { return j({ error: String(e) }, 500) }
})
