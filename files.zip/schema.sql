-- ICT Portal – skema Supabase (jalankan di SQL Editor)
create table if not exists public.records(
  collection text not null,
  id text not null,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (collection, id)
);
create index if not exists records_coll_idx on public.records(collection);
alter table public.records enable row level security;

create or replace function public.my_role() returns text language sql stable security definer set search_path=public as
$$ select data->>'role' from public.records where collection='users' and id=auth.uid()::text $$;
create or replace function public.my_name() returns text language sql stable security definer set search_path=public as
$$ select data->>'nama' from public.records where collection='users' and id=auth.uid()::text $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select coalesce(public.my_role() in ('Manajer','Direktur'), false) $$;

create or replace function public.touch() returns trigger language plpgsql as
$$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists records_touch on public.records;
create trigger records_touch before update on public.records for each row execute function public.touch();

-- BACA
drop policy if exists rec_select on public.records;
create policy rec_select on public.records for select to authenticated using (
  public.is_admin()
  or collection in ('users','cfg','cmenu','mov')
  or collection like 'd\_kpiict%'
  or (collection='chat' and (data->>'r' like 'Grup%' or public.my_name() = any(string_to_array(data->>'r','|'))))
  or (collection='notif' and (data->>'to' in ('*', public.my_name()) or (data->>'to'='@admin' and public.is_admin()) or (data->>'to'='@dir' and public.my_role()='Direktur')))
  or (collection not in ('chat','notif') and collection not like 'd\_kpiict%'
      and (data->>'nama' is null or data->>'nama'=public.my_name()))
);

-- TULIS (insert)
drop policy if exists rec_insert on public.records;
create policy rec_insert on public.records for insert to authenticated with check (
  collection in ('chat','notif')
  or (collection in ('users','cfg','cmenu','mov') and public.my_role()='Manajer')
  or (collection not in ('users','cfg','cmenu','mov') and (
        public.is_admin()
        or (collection not like 'd\_kpiict%'
            and (data->>'nama' is null or data->>'nama'=public.my_name())
            and (collection='d_absen' or coalesce(data->>'status','Menunggu') in ('Menunggu','Open')))))
);

-- UBAH
drop policy if exists rec_update on public.records;
create policy rec_update on public.records for update to authenticated using (
  collection in ('chat','notif')
  or public.my_role()='Manajer'
  or (public.is_admin() and collection not in ('users','cfg','cmenu','mov'))
  or (collection='users' and id=auth.uid()::text)
  or (not public.is_admin() and collection not in ('users','cfg','cmenu','mov') and collection not like 'd\_kpiict%'
      and data->>'nama'=public.my_name()
      and (collection='d_absen' or coalesce(data->>'status','Menunggu') in ('Menunggu','Open')))
) with check (
  collection in ('chat','notif')
  or public.my_role()='Manajer'
  or (public.is_admin() and collection not in ('users','cfg','cmenu','mov'))
  or (collection='users' and id=auth.uid()::text and data->>'role'=public.my_role())
  or (not public.is_admin() and collection not in ('users','cfg','cmenu','mov') and collection not like 'd\_kpiict%'
      and data->>'nama'=public.my_name()
      and (collection='d_absen' or coalesce(data->>'status','Menunggu') in ('Menunggu','Open')))
);

-- HAPUS
drop policy if exists rec_delete on public.records;
create policy rec_delete on public.records for delete to authenticated using (
  public.my_role()='Manajer'
  or (public.is_admin() and collection not in ('users','cfg','cmenu','mov'))
  or (not public.is_admin() and collection not in ('users','cfg','cmenu','mov','chat','notif','d_absen') and collection not like 'd\_kpiict%'
      and data->>'nama'=public.my_name()
      and coalesce(data->>'status','Menunggu') in ('Menunggu','Open'))
);

-- REALTIME
alter publication supabase_realtime add table public.records;

-- ADMIN PERTAMA (jalankan SETELAH membuat user admin@ict.local di Authentication > Users)
-- insert into public.records(collection,id,data)
-- select 'users', id::text, jsonb_build_object('id',id::text,'nama','Nama Anda','username','admin','role','Manajer')
-- from auth.users where email='admin@ict.local';
