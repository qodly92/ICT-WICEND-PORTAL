# Panduan Penerapan ICT Portal di Supabase

Isi paket:

| File | Fungsi |
|---|---|
| `index.html` | Aplikasi lengkap (satu file) yang sudah terhubung ke Supabase |
| `schema.sql` | Tabel, aturan keamanan (RLS), dan realtime |
| `functions/manage-user/index.ts` | Edge Function: Manajer membuat/ubah/hapus akun login |
| `functions/notify-wa/index.ts` | Edge Function: kirim WhatsApp otomatis via Fonnte |

Cara kerja singkat: semua data disimpan di satu tabel `records` (kolom `collection`, `id`, `data` JSON). Login memakai Supabase Auth dengan email `username@ict.local`. Perubahan data tampil real-time di semua perangkat. Setiap pemberitahuan yang tersimpan memicu Edge Function yang mengirim WhatsApp ke orang yang bersangkutan.

---

## 1. Buat project Supabase
1. Masuk ke https://supabase.com → **New project**. Simpan *Database password*.
2. Setelah siap, buka **Project Settings → API**. Catat **Project URL** dan **anon public key**. Jangan pakai `service_role` di `index.html`.

## 2. Jalankan skema database
1. Buka **SQL Editor → New query**, tempel seluruh isi `schema.sql`, klik **Run**.
2. Pastikan tabel `records` muncul di **Table Editor** dan RLS aktif.

## 3. Buat akun Manajer (Super Admin) pertama
1. **Authentication → Users → Add user → Create new user**.
   Email: `admin@ict.local` (format `username@ict.local`), isi password, centang **Auto Confirm User**.
2. Kembali ke **SQL Editor**, jalankan (ganti nama bila perlu):
```sql
insert into public.records(collection,id,data)
select 'users', id::text,
       jsonb_build_object('id',id::text,'nama','Nama Anda','username','admin','role','Manajer')
from auth.users where email='admin@ict.local';
```
3. **Authentication → Sign In / Providers (atau Settings)** → matikan **Allow new users to sign up** agar orang luar tidak bisa mendaftar sendiri. Akun staf nanti dibuat oleh Manajer dari aplikasi.

## 4. Deploy Edge Functions
Pasang Supabase CLI (https://supabase.com/docs/guides/cli), lalu di folder ini:
```bash
supabase login
supabase link --project-ref <PROJECT_ID>
supabase functions deploy manage-user
supabase functions deploy notify-wa
```
`SUPABASE_URL`, `SUPABASE_ANON_KEY`, dan `SUPABASE_SERVICE_ROLE_KEY` sudah tersedia otomatis di dalam function.

> Struktur folder CLI: letakkan `functions/` di dalam folder `supabase/` pada project lokal Anda (`supabase init` membuatnya).

## 5. WhatsApp otomatis (Fonnte)
1. Daftar di https://fonnte.com, tambahkan perangkat (scan QR dengan nomor WhatsApp sekolah), salin **token** perangkat.
2. Simpan token sebagai secret:
```bash
supabase secrets set FONNTE_TOKEN=isi_token_anda
```
3. **Database → Webhooks → Create a new hook**
   - Name: `notify_wa`
   - Table: `records`, Events: **Insert**
   - Type: **Supabase Edge Functions** → pilih `notify-wa`
4. Pastikan nomor WhatsApp pegawai terisi di **Data Profile** (format `0812…` atau `62812…`) dan saklar WhatsApp di **Setting General** aktif.

Hasilnya: pengajuan izin/laporan/tiket, keterlambatan, persetujuan, dan pengumuman otomatis masuk ke WhatsApp penerima. Fonnte adalah layanan pihak ketiga berbayar; Anda bisa menggantinya dengan gateway lain dengan mengubah bagian `fetch` pada `notify-wa`.

## 6. Isi konfigurasi dan pasang aplikasi
1. Buka `index.html`, ganti pada bagian atas script:
```js
const SUPABASE_URL='https://xxxx.supabase.co', SUPABASE_ANON_KEY='eyJ...';
```
2. Unggah `index.html` ke hosting statis (pilih salah satu): **Netlify** (drag & drop folder), **Cloudflare Pages**, **Vercel**, atau **GitHub Pages**. Semuanya gratis untuk kebutuhan ini dan otomatis HTTPS.
3. Buka alamatnya, login dengan username `admin` dan password tadi.

## 7. Tambah pengguna
Menu **Kepegawaian → Data Profile → + Tambah** (Manajer saja): isi nama, username, role (Direktur/Manajer/Staf), nomor WhatsApp, dan password. Aplikasi memanggil `manage-user` untuk membuat akun login, lalu menyimpan profilnya.

## 8. Daftar uji
- [ ] Login admin berhasil, dashboard tampil.
- [ ] Tambah satu Staf dan satu Direktur; login masing-masing di perangkat lain.
- [ ] Staf mengajukan izin → admin menerima notifikasi (lonceng + WhatsApp) tanpa refresh.
- [ ] Admin menyetujui → staf menerima notifikasi.
- [ ] Staf mengunggah laporan → hanya **Direktur** yang melihat tombol Setujui/Tolak.
- [ ] Staf tidak bisa melihat izin milik orang lain dan tidak bisa mengubah status sendiri.
- [ ] Scan barcode ID Card mencatat absen.
- [ ] Ekspor Excel/PDF/JPG berjalan.

## 9. Keamanan dan batasan
- `anon key` memang publik; yang melindungi data adalah **RLS** di `schema.sql`. Jangan mematikan RLS.
- `service_role key` hanya ada di sisi server (Edge Function). Jangan pernah dimasukkan ke `index.html`.
- Aturan RLS menyaring baca/tulis berdasarkan role dan nama. Status "Disetujui/Ditolak" hanya bisa diubah oleh admin. Pengecualian: tabel absensi mengizinkan staf mengubah baris miliknya sendiri lewat aplikasi.
- Foto profil dan berkas laporan saat ini disimpan di dalam data (base64). Disarankan berkas di bawah ±1,5 MB. Untuk berkas besar, ganti ke **Supabase Storage** (bucket `files`) dan simpan URL-nya.
- Login memakai email palsu `username@ict.local` (tidak ada email yang dikirim). Lupa password: Manajer mengubahnya lewat **Edit** pada Data Profile.
- Aktifkan **Point-in-Time Recovery / backup** di plan berbayar, atau ekspor data berkala dari menu Export.

## 10. Pemecahan masalah
| Gejala | Penyebab / solusi |
|---|---|
| "Username atau password salah" padahal benar | Pastikan user dibuat dengan email `username@ict.local` dan **Auto Confirm** dicentang |
| "Akun belum terdaftar di Data Profile" | Baris `users` untuk akun itu belum ada (ulangi langkah 3.2) |
| "Gagal menyimpan ke server" | RLS menolak; cek role pengguna, atau lihat **Logs → Postgres** |
| Tambah user gagal | `manage-user` belum di-deploy, atau yang login bukan Manajer |
| WhatsApp tidak terkirim | Cek webhook aktif, secret `FONNTE_TOKEN`, perangkat Fonnte terhubung, nomor terisi; lihat **Edge Functions → notify-wa → Logs** |
| Data tidak update real-time | Pastikan baris `alter publication supabase_realtime add table public.records;` sudah dijalankan |
